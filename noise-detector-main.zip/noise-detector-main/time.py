import datetime

time = datetime.datetime.now()
print(time.hour, time.minute, time.second)